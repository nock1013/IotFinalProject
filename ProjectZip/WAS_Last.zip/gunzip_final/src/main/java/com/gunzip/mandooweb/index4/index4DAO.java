package com.gunzip.mandooweb.index4;

import java.util.List;

public interface index4DAO {
}
