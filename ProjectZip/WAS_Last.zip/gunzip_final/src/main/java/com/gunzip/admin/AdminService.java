package com.gunzip.admin;

public interface AdminService {
	AdminDTO login(AdminDTO login);
}
