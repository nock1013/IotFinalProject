package com.gunzip.admin;

public interface AdminDAO {
	AdminDTO login(AdminDTO login);
}
