
select * from FCM_TABLE;
create sequence fcm_val;
create table fcm_table(
	num number primary key,
	fcm_token varchar2(500)
)

